import os
import re
import sys
import json
import time
import requests
from hashlib import md5
from functools import reduce
from base64 import b64encode
from difflib import SequenceMatcher
from urllib.parse import urlencode, quote

from redis import ConnectionPool, Redis

redisPool = ConnectionPool(host='127.0.0.1', port=8100, password='password', decode_responses=True, db=0, max_connections=5)

redisClient = Redis(connection_pool=redisPool)

def setCache(key, value):
    if type(value) in [list, tuple, dict, set, str]:
        if len(value) > 0:
            if type(value) in [dict, list, tuple]:
                if type(value) == dict and 'expires_at' in value:
                    redisClient.expireat(key, value['expires_at'])
                value = json.dumps(value, ensure_ascii=False)
            elif type(value) == set:
                value = json.dumps(list(value))
            redisClient.set(key, value)
    elif type(value) in [int, float]:
        redisClient.set(key, value)

def getCache(key):
    value = redisClient.get(key)
    if value:
        if value.startswith('{') and value.endswith('}') or value.startswith('[') and value.endswith(']'):
            value = json.loads(value)
    return value

def delCache(key):
    return redisClient.delete(key)

def getSize(size):
    if size > 1024 * 1024 * 1024 * 1024.0:
        fs = "TB"
        sz = round(size / (1024 * 1024 * 1024 * 1024.0), 2)
    elif size > 1024 * 1024 * 1024.0:
        fs = "GB"
        sz = round(size / (1024 * 1024 * 1024.0), 2)
    elif size > 1024 * 1024.0:
        fs = "MB"
        sz = round(size / (1024 * 1024.0), 2)
    elif size > 1024.0:
        fs = "KB"
        sz = round(size / (1024.0), 2)
    else:
        fs = "KB"
        sz = round(size / (1024.0), 2)
    return str(sz) + fs

def getDanmaku(name, pos, regSrc=None, videoType=None):
    site = ''
    pos = int(pos)
    pos = pos - 1
    urlsList = []
    if pos < 0:
        pos = 0
    try:
        header = {
            'Referer': 'https://so.360kan.com/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36'
        }
        r = requests.get(f'https://api.so.360kan.com/index?force_v=1&kw={name}&from=&pageno=1&v_ap=1&tab=all', headers=header, timeout=15)
        vodList = r.json()['data']['longData'].get('rows')
        for vod in vodList:
            title = vod['titleTxt']
            try:
                for site in vod['vipSite']:
                    if site in ['qq', 'qiyi', 'youku', 'mgtv', 'bilibili']:
                        break
            except:
                try:
                    site = vod['seriesSite']
                except:
                    site = ''
            if videoType and videoType != vod['cat_name']:
                continue

            if vod['cat_name'] in ['动漫', '电视剧']:
                cid = vod['cat_id']
                eid = vod['en_id']
                s = quote(json.dumps([{"cat_id": cid, "ent_id": eid, "site": site}]))
                r = requests.get(f'https://api.so.360kan.com/episodesv2?v_ap=1&s={s}', headers=header, timeout=15)
                data = r.json()['data']
                if data == []:
                    continue
                vod = data[0]['seriesHTML']['seriesPlaylinks']

                if regSrc:
                    try:
                        urlsList.append({'ratio': SequenceMatcher(None, title, name).ratio(), 'url': vod[int(regSrc)-1]['url']})
                    except:
                        try:
                            urlsList.append({'ratio': SequenceMatcher(None, title, name).ratio(), 'url': vod[pos]['url']})
                        except:
                            pass
                else:
                    try:
                        urlsList.append({'ratio': SequenceMatcher(None, title, name).ratio(), 'url': vod[pos]['url']})
                    except:
                        pass

            elif vod['cat_name'] == '综艺':
                eid = vod['id']
                videoList = []
                try:
                    yearList = vod['playlinks_year'][site]
                except:
                    yearList = [vod['year']]
                for year in yearList:
                    offset = 0
                    total = offset + 1
                    while offset < total:
                        try:
                            r = requests.get(f'https://api.so.360kan.com/episodeszongyi?site={site}&y={year}&entid={eid}&offset={offset}&count=20', headers=header, timeout=15)
                            data = r.json()['data']
                            total = data['total']
                            videoList += data['list']
                            offset += 20
                        except:
                            break

                if videoList == []:
                    for key in vod['playlinks']:
                        videoList.append(vod['playlinks'][key][0])
                else:
                    videoList.sort(key=lambda x: int(x['playlink_num']))

                for vod in videoList:
                    if regSrc:
                        try:
                            lenRegSrc = len(regSrc)
                            regResult = str(int(''.join(re.findall(r'\d+', vod['period']))))
                            lenRegResult = len(regResult)
                            if lenRegResult > lenRegSrc:
                                regResult = regResult[lenRegSrc:]
                            else:
                                regResult = regResult.zfill(lenRegSrc)
                        except:
                            regResult = ''
                        if regResult == regSrc:
                            urlsList.insert(0, {'ratio': SequenceMatcher(None, title, name).ratio(), 'url': vod['url']})
                        else:
                            try:
                                urlsList.append({'ratio': SequenceMatcher(None, title, name).ratio(), 'url': videoList[pos]['url']})
                            except:
                                pass
                    else:
                        try:
                            urlsList.append({'ratio': SequenceMatcher(None, title, name).ratio(), 'url': videoList[pos]['url']})
                        except:
                            pass
            elif vod['cat_name'] == '电影':
                try:
                    if pos == 0:
                        urlsList.append({'ratio': SequenceMatcher(None, title, name).ratio(), 'url': vod['playlinks'][site]})
                except:
                    pass
            else:
                continue

        urlsList = sorted(urlsList, key=lambda x: x['ratio'], reverse=True)
        url = re.sub(r'\?.*', '', urlsList[0]['url'])
        if 'qq.com' in url:
            params = {'platform': 'qq', 'url': url}
        elif 'mgtv.com' in url:
            params = {'platform': 'mgtv', 'url': url}
        elif 'iqiyi.com' in url:
            params = {'platform': 'iqiyi', 'url': url}
        elif 'youku.com' in url:
            params = {'platform': 'youku', 'url': url}
        elif 'bilibili.com' in url:
            params = {'platform': 'bilibili', 'url': url}
        else:
            return None
        return params
    except:
        pass

def getDanmuUrl(params):
    return 'http://localUrl/danmu?' + urlencode({'params': json.dumps(params, ensure_ascii=False)})

def getProxyUrl(spider, function, params):
    return 'http://localUrl/proxy?' + urlencode({'spider': spider, 'function': function, 'params': json.dumps(params, ensure_ascii=False)})

def getBBCookie(cookie):
    if type(cookie) == str:
        cookie = dict([co.strip().split('=', 1) for co in cookie.strip(';').split(';')])
    header = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36"
    }
    r = requests.get("http://api.bilibili.com/x/web-interface/nav", cookies=cookie, headers=header, timeout=10)
    data = r.json()
    code = data["code"]
    if code == 0:
        imgKey = data['data']['wbi_img']['img_url'].rsplit('/', 1)[1].split('.')[0]
        subKey = data['data']['wbi_img']['sub_url'].rsplit('/', 1)[1].split('.')[0]
        setCache('bbLogin', 'True')
    else:
        delCache('bbLogin')
        r = requests.get("https://www.bilibili.com/", headers=header, timeout=5)
        cookie = r.cookies.get_dict()
        imgKey = ''
        subKey = ''
    return cookie, imgKey, subKey

def cleanText(src):
    clean = re.sub('[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF]', '', src)
    return clean

def removeHtmlTags(src):
    clean = re.compile('<.*?>')
    return re.sub(clean, '', src)

def removeEmoji(src, xml=False):
    regrexPattern = re.compile(
        pattern="["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
        u"\U00002500-\U00002BEF"  # chinese char
        u"\U00002702-\U000027B0"
        u"\U00002702-\U000027B0"
        u"\U0001f926-\U0001f937"
        u"\U00010000-\U0010ffff"
        u"\u2640-\u2642"
        u"\u2600-\u2B55"
        u"\u200d"
        u"\u23cf"
        u"\u23e9"
        u"\u231a"
        u"\ufe0f"  # dingbats
        u"\u3030"
        u"\b"
        "]+",
        flags=re.UNICODE)
    content = regrexPattern.sub(r'', src)
    if xml:
        patternDict = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            "\"": "&quot;",
            "\'": "&apos;",
            "\x00": " "
        }
        for key in patternDict:
            content = re.sub(r'{}'.format(key), patternDict[key], content)
    return content

def encWbi(params, imgKey, subKey):
    mixinKeyEncTab = [46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52]
    orig = imgKey + subKey
    mixinKey = reduce(lambda s, i: s + orig[i], mixinKeyEncTab, '')[:32]
    params['wts'] = round(time.time())
    params = dict(sorted(params.items()))
    params = {
            k: ''.join(filter(lambda chr: chr not in "!'()*", str(v)))
            for k, v
            in params.items()
        }
    query = urlencode(params)
    params['w_rid'] = md5((query + mixinKey).encode()).hexdigest()
    return params

def intToint36(num):
    chars = "0123456789abcdefghijklmnopqrstuvwxyz"
    if num < 36:
        return chars[num]
    else:
        div, mod = divmod(num, 36)
        return intToint36(div) + chars[mod]

def handleMedia(spider, function, params, proxyUrl='', base64=False):
    url = params['url']
    header = params['header']
    r = requests.get(url, headers=header, stream=True, timeout=30)
    contentType = r.headers['Content-Type']
    if r.status_code != 200:
        return f'网页无法访问，状态码{r.status_code}', 'text/plain', 404
    if not contentType.lower() in ['application/vnd.apple.mpegurl', 'application/x-mpegurl']:
        r.close()
        return url, contentType, 302
    m3u8Str = ''
    strippedImageHeader = True
    localUrl = getCache('localUrl')
    for line in r.iter_lines(8192):
        if strippedImageHeader:
            line = line.lstrip(b'\xFF\xD8\xFF\xE0\x00\x10\x4A\x46\x49\x46')
            line = line.lstrip(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A')
            line = line.lstrip(b'\x47\x49\x46\x38\x37\x61')
            line = line.lstrip(b'\x00\x00\x01\x00')
            line = line.lstrip(b'\x47\x49\x46\x38\x39\x61')
            line = line.lstrip(b'\x42\x4D\x5A\x27\x4C')
            line = line.lstrip(b'\x42\x4D')
            line = line.lstrip(b'\x49\x49')
            strippedImageHeader = False
        line = line.decode()
        if len(line) > 0 and not line.startswith('#'):
            if not line.startswith('http'):
                if line.startswith('/'):
                    line = url[:url.index('/', 8)] + line
                else:
                    line = url[:url.rindex('/') + 1] + line
            if '.m3u8' in line:
                if base64:
                    line = b64encode(line.encode()).decode()
                    newHeader = b64encode(json.dumps(header, ensure_ascii=False).encode()).decode()
                else:
                    newHeader = header.copy()
                params = {'url': line, 'header': newHeader, 'proxyUrl': proxyUrl, 'base64': base64}
                line = getProxyUrl(spider, function, params).replace('http://localUrl', localUrl)
            else:
                if base64:
                    line = b64encode(f'{proxyUrl}{line}'.encode()).decode()
                line = proxyUrl + quote(line)
        elif 'URI=' in line:
            URI = re.search(r'URI=\"(.*?)\"', line).group(1)
            if URI.startswith('/'):
                fullURI = url[:url.index('/', 8)] + URI
            else:
                fullURI = url[:url.rindex('/') + 1] + URI
            line = line.replace(URI, fullURI)
            if base64:
                line = b64encode(line.encode()).decode()
        m3u8Str = m3u8Str + line + '\n'
    return m3u8Str.strip('\n'), contentType, 200

def handleFilesName(item, key):
    return int(re.sub(r"[^\d]", "", item[key].lower().replace('.mp4', '').replace('4k', '').replace('2k', '').replace('2160p', '').replace('1080p', '').replace('720p', '')))

def handleSpider(site, function, params):
    def findSpider(site):
        for root, dirs, files in os.walk('.'):
            for file in files:
                if 'pycache' in root:
                    continue
                fileName = file.lower() if '_' not in file.lower() else file.lower().split('_')[1]
                if site.lower() in fileName:
                    return root[2:], file
        return None, None
    root, spider = findSpider(site)
    if spider:
        if root == '':
            upDirName = os.path.basename(os.path.dirname(os.path.dirname(__file__)))
            if upDirName in ['sites', 'lives']:
                moduleName = f"{upDirName}.{spider[:-3]}"
            else:
                moduleName = spider[:-3]
        else:
            moduleName = f"{root}.{spider[:-3]}"
        __import__(moduleName)
        result = getattr(getattr(sys.modules[moduleName], site)(), function)(params)
        return result
    else:
        return None