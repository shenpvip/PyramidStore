import re
import json
import time
import uvicorn
import binascii
import requests
from PIL import Image
from io import BytesIO
from ddddocr import DdddOcr
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from base64 import b64decode, b64encode
from fastapi import Body, Query, FastAPI, Request, HTTPException
from fastapi.responses import Response, HTMLResponse, FileResponse, RedirectResponse, StreamingResponse

from danmuku import handleDanmu, handleStream
from units import setCache, getCache, delCache, handleSpider, getDanmaku, getBBCookie

# OCR相关
def handleOcr(img: bytes, comp, lenth):
    retry = 1
    result = ''
    ocr = DdddOcr(show_ad=False)
    while retry < 5:
        result = ocr.classification(img)
        if comp == 'digit':
            if result.isdigit():
                if lenth != 0:
                    if len(result) == lenth:
                        break
                else:
                    break
        elif comp == 'alpha':
            if result.isalpha():
                if lenth != 0:
                    if len(result) == lenth:
                        break
                else:
                    break
        elif comp == 'alnum':
            if result.isalnum():
                if lenth != 0:
                    if len(result) == lenth:
                        break
                else:
                    break
        else:
            raise ValueError("识别结果格式或位数错误")
        retry += 1
    return result

def handleDet(img: bytes):
    det = DdddOcr(det=True, show_ad=False)
    return det.detection(img)

def handleCrop(img):
    imgByte = BytesIO()
    img.save(imgByte, format='PNG', subsampling=0, quality=100)
    imgByte = imgByte.getvalue()
    return imgByte

def handleSlide(targetImg: bytes, backgroundImg: bytes):
    slide = DdddOcr(det=False, ocr=False, show_ad=False)
    if len(backgroundImg) == 0:
        imageStream = BytesIO(targetImg)
        imageFile = Image.open(imageStream)
        backgroundImg = imageFile.crop((0, 300, 240, 450))
        cropped = imageFile.crop((0, 0, 240, 150))
        return slide.slide_comparison(handleCrop(cropped), handleCrop(backgroundImg))
    else:
        return slide.slide_match(targetImg, backgroundImg, simple_target=True)

# 开始FastAPI及相关设置
PythonT4 = FastAPI()
# 提供 index.html 文件
@PythonT4.get("/", response_class=HTMLResponse)
def index():
    return FileResponse("templates/index.html")

@PythonT4.get("/PythonT4", response_class=HTMLResponse)
def indexT4():
    return FileResponse("templates/index.html")

# 设置网页图标
@PythonT4.get("/favicon.ico")
def favicon():
    return FileResponse("templates/favicon.ico")

# PythonT4 直播
@PythonT4.get("/live/{site}")
@PythonT4.post("/live/{site}")
def live(request: Request, site: str, params: str):
    try:
        params = json.loads(params)
        if request.url.port:
            localUrl = '{}://{}:{}'.format(request.url.scheme, request.url.hostname, request.url.port)
        else:
            localUrl = '{}://{}'.format(request.url.scheme, request.url.hostname)
        setCache('localUrl', localUrl)
        playUrl = handleSpider(site=site.upper(), function='getInfo', params=params)
        return RedirectResponse(url=playUrl)
    except Exception as e:
        raise HTTPException(status_code=404, detail="错误：{}".format(e))

# PythonT4 点播
@PythonT4.get("/PythonT4/{site}")
@PythonT4.post("/PythonT4/{site}")
def pythonT4(request: Request, site: str, t: str = Query(''), ac: str = Query(''), wd: str = Query(''), pg: int = Query(1), ids: str = Query(''), play: str = Query(''), flag: str = Query(''), ext: str = Query('e30%3D'), extend: str = Query('{}'), quick: bool = Query(False), filter: bool = Query(False), apiInfo: str = Query('')):
    if request.url.port:
        localUrl = '{}://{}:{}'.format(request.url.scheme, request.url.hostname, request.url.port)
    else:
        localUrl = '{}://{}'.format(request.url.scheme, request.url.hostname)
    setCache('localUrl', localUrl)
    if ext == '':
        ext = 'e30%3D'
    params = {
        't': t,
        'ac': ac,
        'wd': wd,
        'pg': pg,
        'ids': ids,
        'ext': ext,
        'play': play,
        'flag': flag,
        'extend': extend,
        'quick': quick,
        'filter': filter
    }
    if apiInfo != '':
        params['apiInfo'] = apiInfo
    try:
        tempkey = site.lower()
        for param in params:
            tempkey = tempkey + "_" + str(params[param])
        content = getCache(tempkey)
        if not content:
            content, expire = handleSpider(site=site.upper(), function='getInfo', params=params)
            setCache(tempkey, {'content': content, 'expires_at': int(time.time()) + expire})
        else:
            content = content['content']
    except Exception as e:
        raise HTTPException(status_code=404, detail="错误：{}".format(e))
    return Response(content=json.dumps(content, ensure_ascii=False).encode(), media_type="text/plain")

# PythonT4代理
@PythonT4.get("/proxy")
def proxy(request: Request, spider: str, function: str, params: str):
    if request.url.port:
        localUrl = '{}://{}:{}'.format(request.url.scheme, request.url.hostname, request.url.port)
    else:
        localUrl = '{}://{}'.format(request.url.scheme, request.url.hostname)
    setCache('localUrl', localUrl)

    def getContent(params):
        url = params['url']
        header = params['header']
        checkHeader = True
        r = requests.get(url, headers=header, stream=True, verify=False)
        for chunk in r.iter_content(8192):
            if checkHeader:
                if chunk.startswith(b'\xFF\xD8\xFF\xE0\x00\x10\x4A\x46\x49\x46') or chunk.startswith(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A') or chunk.startswith(b'\x47\x49\x46\x38\x37\x61') or chunk.startswith(b'\x47\x49\x46\x38\x39\x61') or chunk.startswith(b'\x42\x4D\x5A\x27\x4C') or chunk.startswith(b'\x00\x00\x01\x00') or chunk.startswith(b'\x42\x4D') or chunk.startswith(b'\x49\x49'):
                    chunk = chunk.lstrip(b'\xFF\xD8\xFF\xE0\x00\x10\x4A\x46\x49\x46')
                    chunk = chunk.lstrip(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A')
                    chunk = chunk.lstrip(b'\x47\x49\x46\x38\x37\x61')
                    chunk = chunk.lstrip(b'\x47\x49\x46\x38\x39\x61')
                    chunk = chunk.lstrip(b'\x42\x4D\x5A\x27\x4C')
                    chunk = chunk.lstrip(b'\x00\x00\x01\x00')
                    chunk = chunk.lstrip(b'\x42\x4D')
                    chunk = chunk.lstrip(b'\x49\x49')
                checkHeader = False
            yield chunk
            if len(chunk) == 0:
                try:
                    r.close()
                    break
                except:
                    break
    try:
        params = json.loads(params)
        content, mediaType, status = handleSpider(site=spider.upper(), function=function, params=params)
        if status == 302:
            return RedirectResponse(url=content)
        elif status == 206:
            return StreamingResponse(getContent(content), 200, {'Content-Type': mediaType})
        elif status == 404:
            raise HTTPException(status_code=404, detail="错误：{}".format(content))
        else:
            return Response(content=content, media_type=mediaType)
    except Exception as e:
        raise HTTPException(status_code=404, detail="错误：{}".format(e))

# PythonT4弹幕
@PythonT4.get("/danmu")
def danmu(request: Request, params: str):
    if request.url.port:
        localUrl = '{}://{}:{}'.format(request.url.scheme, request.url.hostname, request.url.port)
    else:
        localUrl = '{}://{}'.format(request.url.scheme, request.url.hostname)
    setCache('localUrl', localUrl)
    try:
        tempkey = params
        params = json.loads(params)

        def getContent(tempkey, params):
            content = ''
            starttime = int(time.time())
            for line in handleStream(params):
                yield (line + '\n').encode()
                content = content + line + '\n'
                if line == '</i>':
                    setCache(tempkey, {'content': content, 'expires_at': int(time.time()) + 14400})
                    break
                if int(time.time()) - starttime >= 600:
                    break

        content = getCache(tempkey)
        if content:
            return Response(content=content['content'], media_type="text/xml")
        else:
            content, stream = handleDanmu(params)
            if stream:
                return StreamingResponse(getContent(tempkey, params), 200, {'Content-Type': 'text/xml'})
            else:
                setCache(tempkey, {'content': content, 'expires_at': int(time.time()) + 14400})
                return Response(content=content, media_type="text/xml")
    except Exception as e:
        raise HTTPException(status_code=404, detail="错误：{}".format(e))

@PythonT4.get("/searchDanmu")
def searchDanmu(params: str):
    try:
        params = json.loads(params)
        result = getDanmaku(params['name'], int(params['pos']), params['regSrc'])
        if result:
            return Response(content=json.dumps(result, ensure_ascii=False).encode(), media_type="text/plain")
        else:
            raise HTTPException(status_code=404, detail="错误：未找到弹幕")
    except Exception as erroInfos:
        raise HTTPException(status_code=404, detail="错误：{}".format(erroInfos))

# 设置缓存
@PythonT4.post("/cache")
async def handleSetCache(request: Request, key: str):
    value = await request.body()
    value = value.decode()
    setCache(key, value)

# 获取缓存
@PythonT4.get("/cache")
def handleGetCache(key: str):
    try:
        content = getCache(key)
        if type(content) == dict or type(content) == list:
            content = json.dumps(content)
        return Response(content=content, media_type="text/plain")
    except Exception as e:
        raise HTTPException(status_code=404, detail="错误：{}".format(e))

# 删除缓存
@PythonT4.delete("/cache")
def handleDeleteCache(key: str):
    result = delCache(key)
    if result == 0:
        raise HTTPException(status_code=404, detail="无法删除，未找到缓存{}".format(key))

# 处理token
@PythonT4.get("/token")
def token(tid: str = Query(''), delFile: bool = Query(False), display: str = Query('token')):
    try:
        content = ''
        if tid == '':
            return "请输入TID"
        with open('token.json', 'r', encoding='utf-8') as file:
            tokenDict = json.loads(file.read())
        tokenList = tokenDict['tokenList']
        tidList = list(tokenList.keys())
        if tid in tidList:
            content = tokenList[tid]
            if display == 'all':
                return Response(content=json.dumps(handleSpider(site="ALI", function="doAliToken", params={'token': tokenList[tid], 'getOpen': True, 'delFile': delFile}), ensure_ascii=False), media_type="text/plain")
            elif display not in ['all', 'token', 'authorization', 'opentoken', 'opauthorization', 'user_id', 'drive_id', 'device_id', 'signature']:
                return Response(content=content, media_type="text/plain")
            else:
                return Response(content=handleSpider(site='ALI', function='doAliToken', params={'token': tokenList[tid], 'getOpen': True, 'delFile': delFile})[display], media_type="text/plain")
        elif tid == 'refreshalltoken':
            if 'num' in tokenDict:
                num = tokenDict['num']
                if num >= len(tokenList):
                    content += '全部{}个token刷新完成\n'.format(num)
                    num = 0
            else:
                num = 0
                tokenDict['num'] = num
            tid = tidList[num]
            tokenList[tid] = handleSpider(site="ALI", function="doAliToken", params={'token': tokenList[tid], 'getOpen': False, 'delFile': True})['token']
            content += '{}：{} 刷新完成'.format(tid, tokenList[tid])
            num += 1
            tokenDict['tokenList'] = tokenList
            tokenDict['num'] = num
            with open('token.json', 'w', encoding='utf-8') as file:
                file.write(json.dumps(tokenDict, ensure_ascii=False))
        return Response(content=content, media_type="text/plain")
    except Exception as e:
        if 'refresh_token' in str(e):
            try:
                del tokenList[tid]
                tokenDict['tokenList'] = tokenList
            except:
                pass
        with open('token.json', 'w', encoding='utf-8') as file:
            file.write(json.dumps(tokenDict, ensure_ascii=False))
        raise HTTPException(status_code=404, detail="错误：{}".format(e))

# 提交参数网页
@PythonT4.get("/token/submit", response_class=HTMLResponse)
def tokenSubmit():
    return FileResponse("templates/submit.html")

# token 处理递交的ID与TOKEN
@PythonT4.post("/token/process")
async def tokenProcess(request: Request):
    try:
        infos = await request.form()
        with open('token.json', 'r', encoding='utf-8') as file:
            tokenDict = json.loads(file.read())
        tokenList = tokenDict['tokenList']
        tidList = list(tokenList.keys())
        if not 'tid' in infos or not 'token' in infos:
            return '请返回填写TID/TOKEN'
        tid = infos['tid']
        token = infos['token']
        if len(token) != 32:
            return 'TOKEN位数错误'
        if tid in tidList:
            return 'TID重复，请返回重新填写'
        tokenList.update({tid: token})
        tokenDict["tokenList"] = tokenList
        with open('token.json', "w", encoding='utf-8') as file:
            file.write(json.dumps(tokenDict, ensure_ascii=False))
        return "成功"
    except Exception as e:
        raise HTTPException(status_code=404, detail="错误：{}".format(e))

# ocr 处理
@PythonT4.post("/ocr")
def ocr(data: dict = Body(...)):
    cookies = {}
    backgroundImgdata = bytes()
    # 获取验证码及所需headers
    if 'header' in data:
        header = data['header']
    else:
        header = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36'
        }
    if 'urlList' in data:
        # 为url则下载并获取cookies
        urlList = data['urlList']
        try:
            if len(urlList) == 1:
                r = requests.get(urlList[0], headers=header, timeout=30)
                for key, value in r.cookies.items():
                    cookies.update({key: value})
                imgdata = r.content
            else:
                imgdata = requests.get(urlList[0], headers=header, timeout=30).content
                backgroundImgdata = requests.get(urlList[1], headers=header, timeout=30).content
        except:
            return {'code': 0, 'result': None, 'msg': '访问{}超时'.format(urlList)}
    elif 'imgList' in data:
        # 为imgList中为imgs的base64解码
        imgList = data['imgList']
        if len(imgList) == 1:
            imgdata = imgList[0]
            if imgdata.startswith('data'):
                imgdata = imgdata.split(',', 1)[1]
            imgdata = b64decode(imgdata)
        else:
            imgdata = imgList[0]
            if imgdata.startswith('data'):
                imgdata = imgdata.split(',', 1)[1]
            imgdata = b64decode(imgdata)
            backgroundImgdata = imgList[1]
            if backgroundImgdata.startswith('data'):
                backgroundImgdata = backgroundImgdata.split(',', 1)[1]
            backgroundImgdata = b64decode(backgroundImgdata)
    else:
        return {'code': 0, 'result': None, 'msg': '没有图片'}
    # 获取ocrType。1：ocr，2：点选，3：滑块。
    if 'ocrType' in data:
        ocrType = data['ocrType']
    else:
        ocrType = 1
    # 获取comp参数，digit-纯数字、alpha-纯字母、alnum-数字和字母
    if 'comp' in data:
        comp = data['comp']
        if comp not in ['digit', 'alpha', 'alnum']:
            comp = 'alnum'
    else:
        comp = 'alnum'
    # 获取lenth参数
    if 'lenth' in data:
        lenth = data['lenth']
        if not lenth.isdigit():
            lenth = 0
        else:
            lenth = int(lenth)
    else:
        lenth = 0
    try:
        if ocrType == 1:
            result = handleOcr(imgdata, comp, lenth)
        elif ocrType == 2:
            result = handleDet(imgdata)
        elif ocrType == 3:
            result = handleSlide(imgdata, backgroundImgdata)
        else:
            return {'code': 0, 'result': None, 'msg': '失败'}
        if not 'urlList' in data or cookies == {}:
            return {'code': 1, 'result': result, 'msg': 'success'}
        else:
            return {'code': 1, 'cookies': cookies, 'result': result, 'msg': 'success'}
    except Exception as e:
        return {'code': 0, 'result': None, 'msg': str(e).strip()}

# img 处理
@PythonT4.post("/rebuildimg")
def rebuildImg(data: dict = Body(...)):
    cookies = {}
    if 'header' in data:
        header = data['header']
    else:
        header = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36'
        }
    if 'imgUrl' in data:
        url = data['imgUrl']
        try:
            r = requests.get(url, headers=header, timeout=30)
            for key, value in r.cookies.items():
                cookies.update({key: value})
            imgData = r.content
        except:
            return {'code': 0, 'result': None, 'msg': '访问{}超时'.format(url)}
    elif 'imgData' in data:
        imgData = data['imgData']
        if imgData.startswith('data'):
            imgData = imgData.split(',', 1)[1]
        imgData = b64decode(imgData)
    else:
        return {'code': 0, 'result': None, 'msg': '没有图片'}
    if 'offsetsDict' in data:
        offsetsDict = data['offsetsDict']
    else:
        return {'code': 0, 'result': None, 'msg': '缺少offsetsList参数'}
    if 'whList' in data:
        whList = data['whList']
    else:
        return {'code': 0, 'result': None, 'msg': 'whList'}
    try:
        weight, height = whList
        imgStream = BytesIO(imgData)
        imgFile = Image.open(imgStream)
        newimgFile = Image.new('RGB', (260, 116))
        if 'upper' in offsetsDict:
            i = 0
            for offset in offsetsDict['upper']:
                offset = (int(offset[0]), int(offset[1]), int(offset[0]) + int(weight), int(offset[1]) + int(height))
                newoffset = (0 + i, 0)
                i += int(weight)
                region = imgFile.crop(offset)
                newimgFile.paste(region, newoffset)
        if 'lower' in offsetsDict:
            i = 0
            for offset in offsetsDict['lower']:
                offset = (int(offset[0]), int(offset[1]), int(offset[0]) + int(weight), int(offset[1]) + int(height))
                newoffset = (0 + i, int(height))
                i += int(weight)
                region = imgFile.crop(offset)
                newimgFile.paste(region, newoffset)
        imgFile = BytesIO()
        newimgFile.save(imgFile, format="PNG")
        imgData = b64encode(imgFile.getvalue()).decode()
        if not 'imgUrl' in data or cookies == {}:
            return {'code': 1, 'result': imgData, 'msg': 'success'}
        else:
            return {'code': 1, 'cookies': cookies, 'result': imgData, 'msg': 'success'}
    except Exception as e:
        return {'code': 0, 'result': None, 'msg': str(e).strip()}

@PythonT4.get("/biliCookies")
@PythonT4.post("/biliCookies")
def handleCookies(act: str = Query('cookie')):
    header = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36",
        "Referer": "https://www.bilibili.com"
    }
    with open('cookie.json', 'r', encoding='utf-8') as file:
        cookieDict = json.loads(file.read())
    cookie, imgKey, subKey = getBBCookie(cookieDict['cookie'])
    refreshToken = cookieDict['refreshToken']

    if act == 'refresh':
        try:
            cipher = PKCS1_OAEP.new(bbRefreshKey, SHA256)
            encrypted = cipher.encrypt(f'refresh_{round(time.time() * 1000)}'.encode())
            correspondPath = binascii.b2a_hex(encrypted).decode()
            url = f'https://www.bilibili.com/correspond/1/{correspondPath}'
            r = requests.get(url, headers=header, cookies=cookie, timeout=5)
            refreshCsrf = re.search(r'<div id="1-name">(\w+)</div>', r.text).group(1)
            params = {'csrf': cookie['bili_jct'], 'refresh_csrf': refreshCsrf, 'source': 'main_web', 'refresh_token': refreshToken}
            r = requests.post('https://passport.bilibili.com/x/passport-login/web/cookie/refresh', data=params, cookies=cookie, headers=header)
            newCookie = requests.utils.dict_from_cookiejar(r.cookies)
            newRefreshToken = r.json()['data']['refresh_token']
            r = requests.post('https://passport.bilibili.com/x/passport-login/web/confirm/refresh', cookies=newCookie, data={'csrf': newCookie['bili_jct'], 'refresh_token': refreshToken}, headers=header)
            if r.status_code != 200 or r.json()['code'] != 0:
                raise HTTPException(status_code=404, detail=f"错误：出现错误，cookies未刷新")
            for key in newCookie:
                try:
                    cookie[key] = newCookie[key]
                except:
                    pass
            content = {'cookie': cookie, 'refreshToken': newRefreshToken}
            with open('cookie.json', 'w', encoding='utf-8') as file:
                file.write(json.dumps(content, ensure_ascii=False))
            return Response(content=json.dumps(cookie, ensure_ascii=False), media_type="text/plain")
        except Exception as e:
            raise HTTPException(status_code=404, detail=f"错误：{e}")
    elif act == 'cookie':
        r = requests.get('https://passport.bilibili.com/x/passport-login/web/cookie/info', params={'csrf': cookie["bili_jct"]}, headers=header, cookies=cookie)
        if r.status_code == 200 and r.json()['data'] and r.json()['data']['refresh']:
            return RedirectResponse(url='/biliCookies?act=refresh')
        return Response(content=json.dumps(cookie, ensure_ascii=False), media_type="text/plain")
    elif act == 'imgKey':
        return Response(content=imgKey, media_type="text/plain")
    elif act == 'subKey':
        return Response(content=subKey, media_type="text/plain")
    else:
        raise HTTPException(status_code=404, detail=f"错误：act-{act}未定义")

bbRefreshKey = RSA.importKey('''\
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDLgd2OAkcGVtoE3ThUREbio0Eg
Uc/prcajMKXvkCKFCWhJYJcLkcM2DKKcSeFpD/j6Boy538YXnR6VhcuUJOhH2x71
nzPjfdTcqMz7djHum0qSZA0AyCBDABUqCrfNgCiJ00Ra7GmRj+YCK1NJEuewlb40
JNrRuoEUXpabUzGB8QIDAQAB
-----END PUBLIC KEY-----''')

# 以8251端口启动服务
uvicorn.run(PythonT4, host="0.0.0.0", port=8251, reload=False)